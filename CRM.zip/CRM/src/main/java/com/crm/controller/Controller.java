package com.crm.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.crm.entity.Customer;
import com.crm.service.Service;

@RestController
public class Controller {

	@Autowired
	Service s;

	@GetMapping("/getdetails")
	public List<Customer> getDetails() {
		return s.getDetails();
	}
	
	@PostMapping("/insert")
	public String insertDetails(@RequestBody Customer c)
	{
		return s.insertDetails(c);
	}
	
	@PutMapping("/update")
	public String updateDetails(@RequestBody Customer c)
	{
		return s.updateDetails(c);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteDetails(@PathVariable int id)
	{
		return s.deleteDetails(id);
	}
	
	@GetMapping("/getnames")
	public List<String> getNames()
	{
		return s.getNames();
	}
}