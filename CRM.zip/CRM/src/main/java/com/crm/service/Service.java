package com.crm.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.crm.dao.Dao;
import com.crm.entity.Customer;

@org.springframework.stereotype.Service
public class Service {

	@Autowired
	Dao d;
	
	public List<Customer> getDetails() {
	
		return d.getDetails();
	}

	public String insertDetails(Customer c) {
		return d.insertDetails(c);
	}

	public String updateDetails(Customer c) {
		return d.updateDetails(c);
	}

	public String deleteDetails(int id) {
		return d.deleteDetails(id);
	}

	public List<String> getNames() {
		return d.getNames();
	}
}