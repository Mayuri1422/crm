package com.crm.dao;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.crm.entity.Customer;

@Repository
public class Dao {

	@Autowired
	SessionFactory sf;

	public List<Customer> getDetails() {

		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Customer.class);
		return criteria.list();
	}

	public String insertDetails(Customer c) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(c);
		tr.commit();
		return "Record Inserted Succesfully";
	}

	public String updateDetails(Customer c) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.update(c);
		tr.commit();
		session.close();
		return "Record Updated Succesfully";
	}

	public String deleteDetails(int id) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Customer c1 = session.load(Customer.class, id);
		session.delete(c1);
		tr.commit();
		session.close();
		return "Record Deleted Succesfully";
	}

	public  List<String> getNames() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Customer.class);
		List<Customer> l = criteria.list();
		List<String> list = new ArrayList<>();
		for (Customer customer : l) {
			list.add(customer.getFname());
		}
		session.close();
		return list;
	}
}