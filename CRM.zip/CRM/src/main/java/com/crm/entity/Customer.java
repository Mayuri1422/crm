package com.crm.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {

	private int id;
	private String fname;
	private String lname;
	private int age;
	private String city;
	private String mobile_number;
	private String lvisit;

	@Id
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobile_number() {
		return mobile_number;
	}

	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}

	public String getLvisit() {
		return lvisit;
	}

	public void setLvisit(String lvisit) {
		this.lvisit = lvisit;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", fname=" + fname + ", lname=" + lname + ", age=" + age + ", city=" + city
				+ ", mobile_number=" + mobile_number + ", lvisit=" + lvisit + "]";
	}
}